#

echo ""
echo ""
echo -e "\033[00;31mTo create the root CA:\033[00;00m"
echo -e "\033[00;35m=======================\033[00;00m"
echo -e "\033[00;33mopenssl req -newkey rsa:1024 -sha1 -config ./myopenssl.cnf  -keyout rootkey.pem -out rootreq.pem\033[00;00m"
openssl req -newkey rsa:1024 -sha1 -config ./myopenssl.cnf  -keyout rootkey.pem -out rootreq.pem -days 3650
echo -e "\033[00;33mopenssl x509 -req -in rootreq.pem -sha1 -extfile ./myopenssl.cnf -extensions v3_ca -signkey rootkey.pem -out rootcert.pem\033[00;00m"
openssl x509 -req -in rootreq.pem -sha1 -extfile ./myopenssl.cnf -extensions v3_ca -signkey rootkey.pem -out rootcert.pem -days 3650
echo -e "\033[00;33mcat rootcert.pem rootkey.pem > root.pem\033[00;00m"
cat rootcert.pem rootkey.pem > root.pem
echo -e "\033[00;33mopenssl x509 -subject -issuer -noout -in root.pem\033[00;00m"
openssl x509 -subject -issuer -noout -in root.pem


echo ""
echo ""
echo -e "\033[00;31mTo create the server CA and sign it with the root CA:\033[00;00m"
echo -e "\033[00;35m=======================================================\033[00;00m"
echo -e "\033[00;33mopenssl req -newkey rsa:1024 -sha1 -config ./myopenssl.cnf   -keyout serverCAkey.pem -out serverCAreq.pem\033[00;00m"
openssl req -newkey rsa:1024 -sha1 -config ./myopenssl.cnf   -keyout serverCAkey.pem -out serverCAreq.pem  -days 3650
echo -e "\033[00;33mopenssl x509 -req -in serverCAreq.pem -sha1 -extfile ./myopenssl.cnf  -extensions v3_ca -CA root.pem -CAkey root.pem  -CAcreateserial -out serverCAcert.pem\033[00;00m"
openssl x509 -req -in serverCAreq.pem -sha1 -extfile ./myopenssl.cnf  -extensions v3_ca -CA root.pem -CAkey root.pem  -CAcreateserial -out serverCAcert.pem  -days 3650
echo -e "\033[00;33mcat serverCAcert.pem serverCAkey.pem rootcert.pem >serverCA.pem\033[00;00m"
cat serverCAcert.pem serverCAkey.pem rootcert.pem >serverCA.pem
echo -e "\033[00;33mopenssl x509 -subject -issuer -noout -in serverCA.pem\033[00;00m"
openssl x509 -subject -issuer -noout -in serverCA.pem



echo ""
echo ""
echo -e "\033[00;31mTo create the server's certificate and sign it with the Server CA:\033[00;00m"
echo -e "\033[00;35m==================================================================\033[00;00m"
echo -e "\033[00;33mopenssl req -newkey rsa:1024 -sha1 -config ./myopenssl.cnf   -keyout serverkey.pem -out serverreq.pem\033[00;00m"
openssl req -newkey rsa:1024 -sha1 -config ./myopenssl.cnf   -keyout serverkey.pem -out serverreq.pem  -days 3650
echo -e "\033[00;33mopenssl x509 -req -in serverreq.pem -sha1 -extfile ./myopenssl.cnf  -extensions usr_cert -CA serverCA.pem -CAkey serverCA.pem  -CAcreateserial -out servercert.pem\033[00;00m"
openssl x509 -req -in serverreq.pem -sha1 -extfile ./myopenssl.cnf  -extensions usr_cert -CA serverCA.pem -CAkey serverCA.pem  -CAcreateserial -out servercert.pem  -days 3650
echo -e "\033[00;33mcat servercert.pem serverkey.pem serverCAcert.pem rootcert.pem > server.pem\033[00;00m"
cat servercert.pem serverkey.pem serverCAcert.pem rootcert.pem > server.pem
echo -e "\033[00;33mopenssl x509 -subject -issuer -noout -in server.pem\033[00;00m"
openssl x509 -subject -issuer -noout -in server.pem




echo ""
echo ""
echo -e "\033[00;31mTo create the client certificate and sign it with the Root CA\033[00;00m"
echo -e "\033[00;35m==============================================================\033[00;00m"
echo -e "\033[00;33mopenssl req -newkey rsa:1024 -sha1 -config ./myopenssl.cnf   -keyout clientkey.pem -out clientreq.pem\033[00;00m"
openssl req -newkey rsa:1024 -sha1 -config ./myopenssl.cnf   -keyout clientkey.pem -out clientreq.pem  -days 3650
echo -e "\033[00;33mopenssl x509 -req -in clientreq.pem -sha1 -extfile ./myopenssl.cnf  -extensions usr_cert -CA root.pem -CAkey root.pem -CAcreateserial -out clientcert.pem\033[00;00m"
openssl x509 -req -in clientreq.pem -sha1 -extfile ./myopenssl.cnf  -extensions usr_cert -CA root.pem -CAkey root.pem -CAcreateserial -out clientcert.pem  -days 3650
echo -e "\033[00;33mcat clientcert.pem clientkey.pem rootcert.pem > client.pem\033[00;00m"
cat clientcert.pem clientkey.pem rootcert.pem > client.pem
echo -e "\033[00;33mopenssl x509 -subject -issuer -noout -in client.pem\033[00;00m"
openssl x509 -subject -issuer -noout -in client.pem



#echo ""
#echo ""
#echo "To create dh512.pem and dh1024.pem:"
#echo "==================================="
#openssl dhparam -check -text -5 512 -out dh512.pem
#openssl dhparam -check -text -5 1024 -out dh1024.pem



echo ""
echo ""
echo -e "\033[00;31mVerify Sign: \033[00;00m"
echo -e "\033[00;35m==================\033[00;00m"
echo -e "\033[00;33mopenssl verify -CAfile  serverCA.pem server.pem\033[00;00m"
openssl verify -CAfile  serverCA.pem server.pem



